import { ControlPanel } from '@/components/live/ControlPanel'
import { LivePageClient } from './LivePageClient'

export default async function LivePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  return <LivePageClient serviceId={id} />
}
